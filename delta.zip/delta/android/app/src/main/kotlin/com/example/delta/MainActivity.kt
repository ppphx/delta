package com.example.delta

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
