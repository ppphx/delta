import 'package:flutter/material.dart';

class ParentClubScreen extends StatelessWidget {
  const ParentClubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> events = [
      {'title': 'Семейный мастер-класс', 'date': '15 мая 2025, 18:00', 'description': 'Учимся готовить вместе!'},
      {'title': 'Вечер вопросов', 'date': '20 мая 2025, 19:00', 'description': 'Обсуждаем воспитание'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Родительский клуб'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Мероприятия и обсуждения',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: events.length,
                itemBuilder: (context, index) {
                  return Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    child: ListTile(
                      title: Text(events[index]['title']!),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(events[index]['date']!),
                          Text(events[index]['description']!),
                        ],
                      ),
                      trailing: const Icon(Icons.event, color: Colors.teal),
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Регистрация на ${events[index]['title']}')),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Открытие чата...')),
                );
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Перейти в чат'),
            ),
          ],
        ),
      ),
    );
  }
}